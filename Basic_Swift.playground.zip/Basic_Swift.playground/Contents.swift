import UIKit

//## Домашнее задание

//1. Исправьте код, чтобы не было ошибки

let optional: Int? = 7
let nonOptional: Int = optional ?? 0

//2. Найдите ошибки

var name: String? = "Test"
var age: Int? = nil
let distance: Float = 26.7
var middleName: String? = nil

//3. Полностью разверните number разными способами

let number: Int??? = 10
if let number1 = number {
    if let number2 = number1 {
        if let number3 = number2 {
            print(number3)
        }
    }
}

//4. Замените значение 15 на 17 в массиве

var numbers = [4, 8, 15, 16, 23, 42]
numbers[2] = 17
//5. Найдите ошибки

let array1 = [Int]()
let array2: [Int] = []
let array3: [String] = []

var array4 = [1, 2, 3]
print(array4[0])
print(array4[2])
array4[1...2]
array4[0] = 4
array4.append(4)

var array5 = [1, 2, 3]
array5[0] = array5[1]
array5[0...1] = [4, 5]
array5[0] = 6
array5[0] += 6
for item in array5 { print(item) }
//
let dict1: [Int: Int] = [:]
let dict2: [String: String] = [:]
let dict3: [Int: Int] = [:]
//
var dict4 = ["One": 1, "Two": 2, "Three": 3]
dict4["One"]
dict4["One"]
dict4["Zero"] = 0
//
var dict5 = ["NY": "New York", "CA": "California"]
dict5["NY"]
dict5["WA"] = "Washington"
dict5["CA"] = nil

//6. Найдите деревенских, но не домашних животных из данных множеств:

let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]

let villageAnimals = farmAnimals.subtracting(houseAnimals)
//7. Сделайте из этого словаря новый словарь со средними рейтингами приложений

let appRatings = [
    "Calendar Pro": [1, 5, 5, 4, 2, 1, 5, 4],
    "The Messenger": [5, 4, 2, 5, 4, 1, 1, 2],
    "Socialise": [2, 1, 2, 2, 1, 2, 4, 2]
]

let newRatings = appRatings.mapValues { Double($0.reduce(0, +)) / Double($0.count) }
print(newRatings)


//8. Получите строку с названиями приложений из предыдущего задания с рейтингом выше 3
newRatings.filter { $0.value > 3}.forEach { print( $0.key )}
//9. Напишите функцию, которая добавляет перед началом переданной строки "Привет, " и выводит результат в консоль
func helloPrint(_ name: String) -> String {
    return "Привет, \(name)"
}
print(helloPrint("mike"))
//10. Напишите функцию, которая принимает имя и фамилию в виде параметров и выводит строку приветствия в консоль
func helloPerson(_ name: String, _ surname: String) -> String {
    return "Привет, \(name) \(surname)"
}
print(helloPerson("mike", "lebovsky"))
//11. Напишите функцию, которая принимает переменное число параметров типа int и возвращает их сумму
func sum(_ numbers: Int...) -> Int {
    return numbers.reduce(0, +)
}
print(sum(1, 2, 2, 3))
//12. Напишите замыкание, которое печатает строку "Привет" и присвойте это замыкание переменной. Вызовите замыкание
let printName = { print("Привет") }
printName()
//13. Напишите замыкание, которое принимает 2 числа и возвращает их сумму. Присвойте это замыкание переменной и вызовите его
let sumNumber = {(_ x: Int, _ y: Int) in return x + y }
sumNumber(1, 2)
//14. Отсортируйте массив [16, 8, 15, 42, 4, 23] по убыванию
[16, 8, 15, 42, 4, 23].sorted(by: >)
//15. Из массива [16, 8, 15, 42, 4, 23] сделайте новый массив с числами больше 10
[16, 8, 15, 42, 4, 23].filter { $0 > 10}.forEach {print( $0 )}
//16. Напишите функцию, которая принимает замыкание в качестве параметра и вызывает его
func callClosures(_ closure: ()) -> () {
    return closure
}
callClosures(printName())
//17. Напишите функцию, которая возвращает замыкание, которое что-то печатает в консоль
callClosures(printName())
//18. Напшите функцию, которая повтораяет переданное замыкание заданное число раз
let text = { return "Hello"}
func closureCalls(_ closure: () -> String, _ number: Int) {
    for _ in 0...number {
        print(closure())
    }
}
closureCalls(text, 6)
//19. Уберите утечку памяти

class Employee { weak var computer: Computer?; deinit { print("deleted")}}
class Computer { var employee: Employee?; deinit { print("deleted")}}

if 1 == 1 {
    let employee: Employee? = Employee()
    let computer: Computer? = Computer()
    employee?.computer = computer
    computer?.employee = employee
}


//20. Уберите утечку памяти

class Counter {
    var value = 0
    lazy var increase = {
        self.value += 1
    }
}


//21. Напишите функцию, которая будет принимать строку и возвращать true, если она есть в любом из двух массивое, либо false в противном случае

let animals1 = ["dog", "cat", "bird", "pig"]
let animals2 = ["turtle", "snake", "lizard", "shark"]

func returnMyString(_ str: String) -> Bool {
    return animals1.contains(str) || animals2.contains(str) ? true : false
}
//22. Напишите функцию, которая считает факториал

func factorial(_ number: Int) -> Int {
    return number == 0 ? 1 : factorial(number - 1) * number
}
factorial(6)
//23. Напишите функцию, которая будет считать сколько раз в массиве встречается цифра 2
func arrayTwoCount(_ array: [Int]) -> Int {
    return array.filter { $0 == 2}.count
}
arrayTwoCount([1, 2, 2, 3, 4, 2, 2, 2])
//24. Напишите функцию, которая будет проверять есть ли среди первых 3 элементов массива цифра 2
func threeBool(_ array: [Int]) -> Bool {
    return array[0...2].contains(2)
}
threeBool([1, 4, 3, 4, 5])
